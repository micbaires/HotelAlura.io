
package mx.com.alurahotel.test;


public class TestIdReservaAleatorio {

    public static void main(String[] args) {
        
        
        
        
    }
}
